# Myostoox

Lecteur audio/vidéo GTK 3 + GStreamer pour bureaux légers (Lubuntu, XFCE, LXQt).

Lancement : `myostoox` ou menu Applications.

Site : https://www.patreon.com/MilOvni
